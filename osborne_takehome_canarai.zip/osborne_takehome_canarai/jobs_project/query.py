import psycopg2
import csv

def export_jobs_to_csv():
    connection = psycopg2.connect(
        host='db',
        user='postgres',
        password='postgres',
        dbname='jobs_db'
    )
    cursor = connection.cursor()

    cursor.execute("SELECT * FROM jobs")
    rows = cursor.fetchall()

    with open('jobs.csv', 'w', newline='') as csvfile:
        csvwriter = csv.writer(csvfile)
        csvwriter.writerow([desc[0] for desc in cursor.description])  # Write headers
        csvwriter.writerows(rows)

    cursor.close()
    connection.close()

if __name__ == "__main__":
    export_jobs_to_csv()
