import scrapy
import json
import os

class JobSpider(scrapy.Spider):
    name = 'job_spider'

    def start_requests(self):
        # Use double backslashes for Windows paths
        files = [
            's01.json',  # Replace with the actual path to your s01.json
            's02.json'   # Replace with the actual path to your s02.json
        ]
        for file in files:
            file_url = 'file://' + os.path.abspath(file)
            yield scrapy.Request(url=file_url, callback=self.parse)

    def parse(self, response):
        data = json.loads(response.text)
        for job in data['jobs']:
            item = {
                'title': job['data']['title'],
                'description': job['data']['description'],
                'location_name': job['data']['location_name'],
                'city': job['data']['city'],
                'state': job['data']['state'],
                'postal_code': job['data']['postal_code'],
            }
            #print("Extracted Job Data: ", item)
            yield item
