# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
import psycopg2

class JobPipeline:
    def __init__(self):
        self.conn = None
        self.cur = None
    
    def open_spider(self, spider):
        # Connect to the PostgreSQL database
        self.conn = psycopg2.connect(
            dbname='jobs_db',
            user='postgres',
            password='postgres',  # Replace with your PostgreSQL password

            #host='localhost'
            host='db'
        )
        self.cur = self.conn.cursor()

    def close_spider(self, spider):
        # Close the connection
        self.cur.close()
        self.conn.close()

    def process_item(self, item, spider):
        # Insert the item into the PostgreSQL table
       
        self.cur.execute(
            """INSERT INTO jobs (title, description, location_name, city, state, postal_code)
            VALUES (%s, %s, %s, %s, %s, %s)""",
            (item['title'], item['description'], item['location_name'], item['city'], item['state'], item['postal_code'])
        )
        self.conn.commit()
        return item

